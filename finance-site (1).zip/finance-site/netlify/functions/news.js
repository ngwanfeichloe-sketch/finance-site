// Fetches a Google News RSS feed on Netlify's servers and returns it to the page.
// CommonJS form (exports.handler) — this is what Netlify runs reliably.
// No CORS issues (same origin), no API key, runs on Netlify's free tier.
exports.handler = async (event) => {
  try {
    const target = event.queryStringParameters && event.queryStringParameters.url;
    if (!target || !/^https:\/\/news\.google\.com\/rss\//.test(target)) {
      return { statusCode: 400, body: "Missing or invalid url parameter" };
    }
    const res = await fetch(target, {
      headers: { "User-Agent": "Mozilla/5.0 (FinancePathways Markets Desk)" }
    });
    const xml = await res.text();
    return {
      statusCode: 200,
      headers: {
        "content-type": "application/xml; charset=utf-8",
        "access-control-allow-origin": "*",
        "cache-control": "public, max-age=600"
      },
      body: xml
    };
  } catch (e) {
    return { statusCode: 502, body: "Fetch failed: " + String(e) };
  }
};
