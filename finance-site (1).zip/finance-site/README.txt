START HERE: open HOW-TO-PUT-IT-ONLINE.md for the step-by-step guide.

Quick version:
  1. Upload all the files in this folder to a free GitHub repo
     (github.com -> New repository -> Add file -> Upload files).
  2. Connect that repo to Netlify (app.netlify.com -> Add new site ->
     Import from GitHub). Click Deploy. Done.
Deploying via GitHub (not drag-and-drop) is what makes the live news work,
because Netlify then builds the included news helper automatically.
