# Putting your Finance Pathways site online — no coding

You'll use two free websites: **GitHub** (stores the files) and **Netlify**
(turns them into a live web page). It's all clicking and dragging — about
10 minutes. Do the parts in order.

**Before you start:** unzip the `finance-site` folder so you can see what's
inside: `index.html`, `dashboard.html`, `quiz.html`, `netlify.toml`, and a
folder called `netlify`.

---

## Part 1 — Put the files on GitHub

1. Go to **github.com** and click **Sign up**. Make a free account (email + password).
2. Once logged in, click the **+** icon (top-right) → **New repository**.
3. Name it something like **finance-pathways**. Leave everything else as the
   default (Public is fine). Click **Create repository**.
4. On the next page, click the blue link **"uploading an existing file"**
   (or the **Add file** button → **Upload files**).
5. Open your unzipped `finance-site` folder. Select **everything inside it** —
   the three `.html` files, `netlify.toml`, **and** the `netlify` folder — and
   drag them all into the upload box in the browser.
   *(Tip: select the items inside the folder, not the `finance-site` folder itself.)*
6. Wait until everything finishes uploading (you'll see `netlify/functions/news.js`
   listed too). Then scroll down and click **Commit changes**.

**Success looks like:** your repo page now lists `index.html`, `dashboard.html`,
`quiz.html`, `netlify.toml`, and a `netlify` folder.

---

## Part 2 — Make it live with Netlify

7. Go to **app.netlify.com**. Click **Sign up** → choose **"Sign up with GitHub"**
   (easiest — it links the two accounts). Authorize when asked.
8. Click **Add new site** → **Import an existing project** → **Deploy with GitHub**.
9. If asked, allow Netlify to see your repositories. Then pick your
   **finance-pathways** repo from the list.
10. It shows some build settings — **you don't need to change anything.**
    Just click **Deploy**.
11. Wait about a minute. When it says **Published**, click the link at the top
    (it looks like `random-words-1234.netlify.app`).

**Success looks like:** the site opens, and on the dashboard the "Live headlines"
sections fill with news. (Give it a few seconds the first time.)

---

## Nice extras (optional)

- **Rename the site:** in Netlify → **Site configuration** → **Change site name**
  → pick something like `finance-pathways`.
- **Your pages:**
  - landing page → `yoursite.netlify.app`
  - dashboard → `yoursite.netlify.app/dashboard.html`
  - quiz → `yoursite.netlify.app/quiz.html`

---

## If the news still doesn't appear

1. Wait 10–15 seconds and refresh the page once.
2. If a box says **"Couldn't reach the live news feed,"** there's a small
   **"What it tried:"** list right under it. Send me those lines — they tell me
   the exact thing to fix.
3. **Guaranteed backup** (works no matter what): get a free key at **rss2json.com**,
   then on GitHub open `dashboard.html`, click the pencil (Edit) icon, find the
   line `const RSS2JSON_KEY = "";`, paste your key between the quotes, and click
   **Commit changes**. Netlify updates the site automatically. I can talk you
   through this if you get stuck.

That's it — you'll have a real, live, auto-updating site.
